<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <img alt="Flask logo" src="../assets/flasklogo.png">
  </div>
  <h2>
      Image repository Built with Vue.js + flask
  </h2>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'Home',
};
</script>
