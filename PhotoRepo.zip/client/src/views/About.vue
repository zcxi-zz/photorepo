<template>
  <div class="about" height="500">
    <h1>Features</h1>
    <h3> Batch upload</h3>
      <p>
        Upload unlimited files at once up to 10MB per file* (Content size limit untested on Heroku)
      </p>
    <h3> Batch delete</h3>
      <p>
        Select many photos at once and use delete button to erase them from server
      </p>
    <h3> Not working</h3>
      <p>
        Page refresh: Vue router is on history mode
      </p>
  </div>
</template>
